import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    passwd="2801",
    database="user_info"  # Replace 'your_database_name' with your database name
)

class user_login_info:
    def __init__(self):
        pass 
    
    def exists(self, email):
        cursor = mydb.cursor() 
        try: 
            cursor.execute("SELECT email FROM user_table WHERE email = %s", (email,))
            existing_email = cursor.fetchone()

            if existing_email: 
                return True
            return False
        except mysql.connector.Error as error:
            print(f"Error checking user existence: {error}")
            return False
        finally: 
            cursor.close() 

    def insert(self, name, email, password):
        cursor = mydb.cursor()
        try:
            # Check if the email already exists
            if self.exists(email): 
                print("User with this email already exists. Not adding.")
            else:
                query = "INSERT INTO user_table (name, email, password) VALUES (%s, %s, %s)"
                val = (name, email, password)
                cursor.execute(query, val)
                mydb.commit()
                print("User inserted successfully!")
        except mysql.connector.Error as error:
            print(f"Failed to insert user: {error}")
        finally:
            cursor.close()

    def get_password(self, email):
        cursor = mydb.cursor() 
        try: 
            if self.exists(email):
                query = "SELECT password FROM user_table WHERE email = %s"
                cursor.execute(query, (email,))
                password = cursor.fetchone()
                if password:
                    return password[0]  # Return password
                else:
                    return None  # Email not found
        except mysql.connector.Error as error:
            print(f"Error retrieving password: {error}")
            return None
        finally:
            cursor.close()




class admin_login_info:
    def __init__(self):
        pass 
    
    def exists(self, email):
        cursor = mydb.cursor() 
        try: 
            cursor.execute("SELECT email FROM admin_table WHERE email = %s", (email,))
            existing_email = cursor.fetchone()

            if existing_email: 
                return True
            return False
        except mysql.connector.Error as error:
            print(f"Error checking admin existence: {error}")
            return False
        finally: 
            cursor.close() 

    def insert(self, name, email, password):
        cursor = mydb.cursor()
        try:
            # Check if the email already exists
            if self.exists(email): 
                print("admin with this email already exists. Not adding.")
            else:
                query = "INSERT INTO admin_table (name, email, password) VALUES (%s, %s, %s)"
                val = (name, email, password)
                cursor.execute(query, val)
                mydb.commit()
                print("admin inserted successfully!")
        except mysql.connector.Error as error:
            print(f"Failed to insert admin: {error}")
        finally:
            cursor.close()

    def get_password(self, email):
        cursor = mydb.cursor() 
        try: 
            if self.exists(email):
                query = "SELECT password FROM admin_table WHERE email = %s"
                cursor.execute(query, (email,))
                password = cursor.fetchone()
                if password:
                    return password[0]  # Return password
                else:
                    return None  # Email not found
        except mysql.connector.Error as error:
            print(f"Error retrieving password: {error}")
            return None
        finally:
            cursor.close()
