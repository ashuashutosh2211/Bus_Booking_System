
g.connect()
ep = g.get_edge_properties("city1" , "city2" )
print(ep)