from flask import Flask
from neo4j import GraphDatabase

# app = Flask(__name__)

class CityGraphs:
    def __init__(self):
        self.__url = "bolt://localhost:7687"
        self.__username = "neo4j"
        self.__password = "password"
        self.driver = None

    def connect(self):
        self.driver = GraphDatabase.driver(self.__url, auth=(self.__username, self.__password))

    # def close(self):
    #     if self.driver is not None:
    #         self.driver.close()

    def execute_query(self, query, parameters=None):
        with self.driver.session() as session:
            result = session.run(query, parameters)
            return result

    def create_node(self, city):
        query = (
            "MERGE (c:City {city_name: $city}) "
            "RETURN c"
        )
        parameters = {"city": city}
        return self.execute_query(query, parameters)

    # def create_path(self, city1, city2, date, time, bus_num):
    #     query = (
    #         "MATCH (from:City {city_name: $city1}) "
    #         "MATCH (to:City {city_name: $city2}) "
    #         "CREATE (from)-[r:TRAVELS_TO {date: $date, time: $time, bus_num: $bus_num}]->(to) "
    #         "RETURN r.date , r.bus_num ;"
    #     )
    #     parameters = {"city1": city1, "city2": city2, "date": date, "time": time, "bus_num": bus_num}
    #     return self.execute_query(query, parameters)
    def create_path(self, city1, city2, date, time, bus_num, passengers, expected_arrival , price):
        query = (
            "MATCH (from:City {city_name: $city1}) "
            "MATCH (to:City {city_name: $city2}) "
            "CREATE (from)-[r:TRAVELS_TO {date: $date, time: $time, bus_num: $bus_num, passengers: $passengers, expected_arrival: $expected_arrival , price : $price}]->(to) "
            "RETURN r.date , r.bus_num ;"
        )
        parameters = {
            "city1": city1,
            "city2": city2,
            "date": date,
            "time": time,
            "bus_num": bus_num,
            "passengers": passengers,
            "expected_arrival": expected_arrival,
            "price" : price 
        }
        return self.execute_query(query, parameters)

    def get_search_result(self, city1, city2 , date ):
        query = (
            "MATCH (from:City {city_name: $city1})-[r:TRAVELS_TO]->(to:City {city_name: $city2}) "
            "RETURN properties(r) as edge_properties"
        )
        parameters = {"city1": city1, "city2": city2}
        # return self.execute_query(query, parameters)
        x = []
        with self.driver.session() as session:
            result = session.run(query, parameters)
            for r in result:
                if(r['edge_properties']['date'] == date ) : 
                    formatted_result = {
                        "from_city_name": city1,
                        "to_city_name": city2,
                        **r['edge_properties'],
                    }
                    x.append(formatted_result)
                    # x.append(dict(r['edge_properties']))
        return x
    def get_available_seats(self, bus_num, date, time):
        query = (
            "MATCH (from:City)-[r:TRAVELS_TO]->(to:City) "
            "WHERE r.bus_num = $bus_num AND r.date = $date AND r.time = $time "
            "RETURN r.passengers AS available_seats"
        )
        parameters = {"bus_num": bus_num, "date": date, "time": time}
        # result = self.execute_query(query, parameters)
        # return result.single().get("available_seats", 0)
        with self.driver.session() as session:
            result = session.run(query, parameters)
            for r in result:
                return r['available_seats']

    # New method to confirm booking and update available seats
    def confirm_booking(self, bus_num, date, time, passengers):
        query = (
            "MATCH (from:City)-[r:TRAVELS_TO]->(to:City) "
            "WHERE r.bus_num = $bus_num AND r.date = $date AND r.time = $time "
            "SET r.passengers = CASE WHEN r.passengers - $passengers < 0 THEN 0 ELSE r.passengers - $passengers END "
        )
        parameters = {"bus_num": bus_num, "date": date, "time": time, "passengers": passengers}
        self.execute_query(query, parameters)
        
# g = CityGraphs()
# g.connect()
# ep = g.get_search_result("city1" , "city2" , "2024-02-21" )
# print(ep)
# # print(ep)
# records = ep.data()

# if records:
#     for record in records:
#         edge_properties = record["edge_properties"]
#         print(edge_properties)
# else:
#     print("No edge properties found.")

