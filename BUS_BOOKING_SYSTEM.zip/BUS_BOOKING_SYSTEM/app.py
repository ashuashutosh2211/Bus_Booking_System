from flask import Flask, render_template, request, redirect, url_for, session, flash
from my_sql_databse import user_login_info, admin_login_info
from city_connections import CityGraphs
app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

user_info = user_login_info()
admin_info = admin_login_info()
city_graph = CityGraphs()
city_graph.connect()

@app.route('/' )
def main_page():
    return render_template('index.html')


# Signup page
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
      
        isadmin = request.form.get('user_type') == 'admin'
        
        if(isadmin == False and user_info.exists( email ) == False ) : 
            user_info.insert(name , email , password )
            return redirect(url_for('login'))  # Redirect to login after signup
        elif (isadmin == True and admin_info.exists(email) == False ) : 
            admin_info.insert(name , email , password  ) 
            return redirect(url_for('login'))  # Redirect to login after signup
        else:
            return render_template('signup.html', message='Email already exists. Please use a different email or login')
    return render_template('signup.html')


# Login page
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        is_admin = request.form.get('login_type') == 'admin'
        
        if not is_admin and user_info.exists(email) and password == user_info.get_password(email):
            session['logged_in'] = True
            # return redirect(url_for('user_dashboard'))
            return user_dashboard()
        elif is_admin and admin_info.exists(email) and password == admin_info.get_password(email):
            session['logged_in'] = True
            # return redirect(url_for('dashboard', user_type='admin'))
            return admin_dashboard()
        else:
            return render_template('login.html', message='Invalid credentials. Please try again.')

    return render_template('login.html')

# @app.route('/dashboard/<user_type>')
# def dashboard(user_type):
#     if 'logged_in' in session and session['logged_in']:
#         if user_type == 'admin':
#             return render_template('admin_dashboard.html')
#         elif user_type == 'user':
#             return render_template('user_dashboard.html')
#         else:
#             return render_template('error.html', message='Invalid user type.')
#     else:
#         return redirect(url_for('login'))


@app.route('/logout', methods=['POST'])
def logout():
    session.clear()  # Clear the session data
    return redirect(url_for('login')) 

# from sys import stderr
# @app.route('/dashboard/admin', methods=['GET', 'POST'])
# def admin_dashboard():
#     if request.method == 'POST':
#         # print("HELLO")
#         from_city = request.form.get('from_city')
#         to_city = request.form.get('to_city')
#         bus_num = request.form.get('bus_num')
#         date = request.form.get('date')
#         time = request.form.get('time')
#         city_graph.create_node(from_city)
#         city_graph.create_node(to_city) 
#         city_graph.create_path(from_city , to_city , date , time , bus_num ) 
        
        
#     return render_template('admin_dashboard.html') 
# Flask Route for Admin Dashboard
# ...

@app.route('/dashboard/admin', methods=['GET', 'POST'])
def admin_dashboard():
    if request.method == 'POST':
        from_city = request.form.get('from_city')
        to_city = request.form.get('to_city')
        bus_num = request.form.get('bus_num')
        date = request.form.get('date')
        time = request.form.get('time')
        passengers = request.form.get('passengers')  # Retrieve number of passengers
        expected_arrival = request.form.get('expected_arrival')  # Retrieve expected arrival time
        price = request.form.get('price')  # Retrieve the price
        
        # Create nodes for cities if needed
        city_graph.create_node(from_city)
        city_graph.create_node(to_city)
        
        # Create path with additional parameters including the new "Price" field
        city_graph.create_path(from_city, to_city, date, time, bus_num, passengers, expected_arrival, price)
        
        # Redirect to the admin dashboard (or any other page as needed after adding the bus)
        return redirect(url_for('admin_dashboard'))
        
    return render_template('admin_dashboard.html')

# ...



# @app.route('/dashboard/user', methods=['GET', 'POST'])
# def user_dashboard():
#     if request.method == 'POST':
#         from_city = request.form.get('from_city')
#         to_city = request.form.get('to_city')
#         date = request.form.get('date')
     
#         if from_city and to_city and date:
#             print("HELLO WORLD")
#             result = city_graph.get_search_result(from_city, to_city, date)

#             print(result) 
#             return render_template('user_dashboard.html')
#         else:
#             # Handle case when form fields are empty
#             return render_template('user_dashboard.html', message='Please fill in all fields')

#     # This part will render the initial user_dashboard.html page for GET requests
#     return render_template('user_dashboard.html')

def calculate_total_price(price_per_seat, passenger_count):
    return price_per_seat * passenger_count

@app.route('/dashboard/user', methods=['GET', 'POST'])
def user_dashboard():
    if request.method == 'POST':
        from_city = request.form.get('from_city')
        to_city = request.form.get('to_city')
        date = request.form.get('date')

        if from_city and to_city and date:
            result = city_graph.get_search_result(from_city, to_city, date)
            return render_template('search_results.html', search_result=result)
        else:
            return render_template('user_dashboard.html', message='Please fill in all fields')

    elif request.method == 'GET':
        return render_template('user_dashboard.html')

@app.route('/book_ticket', methods=['POST'])
def book_ticket():
    if request.method == 'POST':
        bus_num = request.form.get('bus_num')
        date = request.form.get('date')
        time = request.form.get('time')
        passengers = int(request.form.get('passengers'))

        # Call a method to update the available seats in your Neo4j database
        city_graph.update_available_seats(bus_num, date, time, passengers)

        # You might want to redirect to a confirmation page or the search results
        return redirect(url_for('user_dashboard'))



if __name__ == '__main__':
    app.run(debug=True , port= 9000)
